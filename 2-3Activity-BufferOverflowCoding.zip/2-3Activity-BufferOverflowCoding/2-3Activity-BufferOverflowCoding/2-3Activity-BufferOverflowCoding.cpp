// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	const std::string account_number = "CharlieBrown42";
	char user_input[20];

	std::cout << "Enter a value: ";
	// Limit user input to a max of 20 characters to prevent possible overflow
	std::cin.width(20);
	std::cin >> user_input;

	// Check user input and display error message if input character limit is exceeded
	if (std::cin.peek() != '\n') {
		std::cin.clear();  // clear any possible errors caused by exceeding width limit
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clean up excess characters in input buffer
		std::cerr << "Too many characters entered. Please limit characters to a maximum of 20." << std::endl;
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
