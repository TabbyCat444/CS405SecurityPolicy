// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>  // import standard exception library
#include <fstream>  // for log file
#include <ctime> // for log file timestamps

// Define custom exception class
class SpaghettiOsException : public std::exception {
public:
    // Override what() to throw custom message
    const char* what() const noexcept override {
        return "Uh-Oh! SpaghettiOs!";
    }
};

// ~~~ IMPLEMENT LOGGING ~~~ //
// Define logging function with provided information and log level (this application currently only utilizes "INFO" and "ERROR")
void log_info(const std::string& log_info, const std::string& level = "INFO") {
    // Try to create timestamp based on current time
    std::time_t now = std::time(nullptr);
    char timestamp_buffer[26];
    if (ctime_s(timestamp_buffer, sizeof(timestamp_buffer), &now) != 0) {
        std::cerr << "Error formatting timestamp." << std::endl;
        return;
    }
    timestamp_buffer[24] = '\0';

    // Handle creating, opening, writing to, and closing log text file
    std::ofstream logfile("exceptions.log", std::ios::app);
    if (logfile.is_open()) {
        logfile << timestamp_buffer << " [" << level << "] " << log_info << std::endl;
        logfile.close();
    }

    else {
        std::cerr << "Error opening log file." << std::endl;
        std::cerr << timestamp_buffer << " [ERROR] Unable to open log file. " << log_info << std::endl;
    }
}

bool do_even_more_custom_application_logic() {
    // Throw logic_error standard exception
    throw std::logic_error("Some logic didn't logic in 'do_even_more_custom_application_logic'");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    /*
    Wrap the call to do_even_more_custom_application_logic() with an exception handler that catches std::exception, logs it,
    displays a message and the exception.what(), then continues processing
    */ 
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    catch (const std::exception& e) {
        std::string error_info = "Exception caught in 'do_custom_application_logic': " + std::string(e.what());
        log_info(error_info, "ERROR");
        std::cerr << error_info << std::endl;
    }

    // Throw custom exception derived from std::exception and catch it explictly in main
    throw SpaghettiOsException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den) {
    // Throw standard invalid argument exception to deal with divide by zero errors
    if (den == 0) {
        throw std::invalid_argument("Invalid Argument! Cannot divide by 0!");
    }

    return (num / den);
}

void do_division() noexcept {
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Exception handler to catch, and log, exception thrown by divide.
    catch (const std::invalid_argument& e) {
        std::string error_info = "Exception caught in 'do_division': " + std::string(e.what());
        log_info(error_info, "ERROR");
        std::cerr << error_info << std::endl;
    }
}

int main() {
    log_info("Program Start");
    std::cout << "~~~ Exceptions Tests! ~~~" << std::endl;
     
    // ~~~ Catch All Exception Handlers ~~~ //
    try {
        do_division();
        do_custom_application_logic();
    }

    // Catch, and log, custom exception
    catch (const SpaghettiOsException& e) {
        std::string error_info = "Caught custom exception from 'do_custom_application_logic' in main: " + std::string(e.what());
        log_info(error_info, "ERROR");
        std::cerr << error_info << std::endl;
    }

    // Catch, and log, standard exception
    catch (const std::exception& e) {
        std::string error_info = "Caught standard exception from 'do_custom_application_logic' in main: " + std::string(e.what());
        log_info(error_info, "ERROR");
        std::cerr << error_info << std::endl;
    }

    // Catch, and log, any other exception
    catch (...) {
        log_info("Caught unknown exception from 'do_custom_application_logic' in main.", "ERROR");
        std::cerr << "Caught unknown exception in main." << std::endl;
    }

    log_info("Program End");
}
